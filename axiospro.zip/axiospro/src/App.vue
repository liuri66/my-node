<script setup>
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <div>
   
  </div>
  <HelloWorld  />
</template>

<style scoped>

</style>
